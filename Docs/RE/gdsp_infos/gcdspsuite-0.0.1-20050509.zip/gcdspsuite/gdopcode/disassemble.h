#pragma once

bool disassemble(char *name, FILE *output);


extern uint8	decode_names;
extern uint8	decode_registers;
extern uint8	show_hex;
