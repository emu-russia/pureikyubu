#pragma once

void dbg_error(char *msg);